# PickleFlow prototype

Open `index.html` in Chrome, Edge, Safari, or Firefox.

Current prototype features:
- Dynamic player roster
- Private 1.0–5.0 skill ratings
- Active / Temporarily Out / Leaving After Round / Left Session statuses
- Duplicate-name protection
- 1–20 courts
- Open-ended or reserved-until session
- Smart Random
- Similar Skill
- Balanced Teams
- Mix-It-Up
- Fair sit-out tracking
- Partner/opponent history
- Organizer-facing court assignments
- Browser-local persistence
- Export session JSON

Not yet included:
- QR self check-in/out
- Multi-device live syncing
- Timers
- Winner recording
- Adaptive rating / Adaptive mode
- Persistent cross-session profiles

Those require moving from a single-browser prototype to a small hosted backend/database.
